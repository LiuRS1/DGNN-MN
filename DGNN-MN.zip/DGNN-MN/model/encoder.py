import torch
from torch import nn
import numpy as np
import dgl.function as fn
from modules.memory import Memory
from modules.message_aggregator import get_message_aggregator
from modules.message_function import get_message_function
from modules.memory_updater import get_memory_updater
from modules.embedding_module import get_embedding_module
from collections import defaultdict

class Encoder(nn.Module):
    def __init__(self, args, emb_dim, n_head=2, dropout=0.1, use_mask=False,USE_MEMORY=False):
        super(Encoder, self).__init__()
        self.args = args

        self.use_source_embedding_in_message = False
        self.dyrep = False
        self.use_destination_embedding_in_message = False

        self.attn_aggr = mail_attn_agger(emb_dim, n_head, dropout)
        self.time_encoder = TimeEncode(emb_dim)
        len_mail = args.n_mail
        self.pos_encoder = PosEncode(emb_dim, len_mail)
        self.merger = MergeLayer((emb_dim)*2, emb_dim, dropout=dropout)
        self.use_mask = use_mask

        self.use_memory = USE_MEMORY

        self.N_Nodes = 9227
        if self.use_memory:
            device = torch.device('cuda:0')
            self.device = device
            self.memory_dimension = 172 # 172
            self.memory_update_at_start = True  # True
            raw_message_dimension = 172+172+172
            # 2 * self.memory_dimension + self.n_edge_features + \
            #                         self.time_encoder.dimension  # 2*172 + 4 + 172 = 520
            message_dimension = raw_message_dimension#message_dimension if message_function != "identity" else raw_message_dimension  # 520
            self.memory = Memory(n_nodes=self.N_Nodes,  # 7048
                                 memory_dimension=172,  # 172
                                 input_dimension=message_dimension,  # 520
                                 message_dimension=message_dimension,  # 520
                                 device=device)
            self.message_aggregator = get_message_aggregator(aggregator_type='last',  # last
                                                             device=device)
            self.message_function = get_message_function(module_type='identity',  # 'identity'
                                                         raw_message_dimension=raw_message_dimension,  # 520
                                                         message_dimension=message_dimension)  # 520
            self.memory_updater = get_memory_updater(module_type='gru',  # 'gru'
                                                     memory=self.memory,
                                                     message_dimension=message_dimension,  # 520
                                                     memory_dimension=self.memory_dimension,  # 172
                                                     device=device)

    def get_updated_memory(self, nodes, messages):
        # Aggregate messages for the same nodes
        unique_nodes, unique_messages, unique_timestamps = \
            self.message_aggregator.aggregate(
                nodes,
                messages)

        if len(unique_nodes) > 0:
            unique_messages = self.message_function.compute_message(unique_messages)

        updated_memory, updated_last_update = self.memory_updater.get_updated_memory(unique_nodes,
                                                                                     unique_messages,
                                                                                     timestamps=unique_timestamps)

        return updated_memory, updated_last_update

    def get_raw_messages(self, source_nodes, source_node_embedding, destination_nodes,
                         destination_node_embedding, edge_times):
        edge_times = (edge_times).float().to(self.device)
        #edge_features = self.edge_raw_features[edge_idxs]

        source_memory = self.memory.get_memory(source_nodes) if not \
            self.use_source_embedding_in_message else source_node_embedding
        destination_memory = self.memory.get_memory(destination_nodes) if \
            not self.use_destination_embedding_in_message else destination_node_embedding

        source_time_delta = edge_times - self.memory.last_update[source_nodes]
        source_time_delta_encoding = self.time_encoder(source_time_delta.unsqueeze(dim=1)).view(len(
            source_nodes), -1)

        source_message = torch.cat([source_memory, destination_memory, #edge_features,
                                    source_time_delta_encoding],
                                   dim=1)
        messages = defaultdict(list)
        unique_sources = np.unique(source_nodes)

        for i in range(len(source_nodes)):
            messages[source_nodes[i]].append((source_message[i], edge_times[i]))

        return unique_sources, messages

    def update_memory(self, nodes, messages):
        # Aggregate messages for the same nodes
        unique_nodes, unique_messages, unique_timestamps = \
            self.message_aggregator.aggregate(
                nodes,
                messages)

        if len(unique_nodes) > 0:
            unique_messages = self.message_function.compute_message(unique_messages)

        # Update the memory with the aggregated messages
        self.memory_updater.update_memory(unique_nodes, unique_messages,
                                          timestamps=unique_timestamps)

    def forward(self, pos_graph, neg_graph, num_pos_nodes):


        mail = pos_graph.ndata['mail']

        mask = None
        if self.use_mask:
            mask = (mail.mean(2)==0).bool()
            mask[:,0] = 0

        if self.use_memory:
            if self.memory_update_at_start:
                # Update memory for all nodes with messages stored in previous batches
                memory, last_update = self.get_updated_memory(list(range(self.N_Nodes)),  # 7048
                                                              self.memory.messages)
            else:
                memory = self.memory.get_memory(list(range(self.n_nodes)))
                last_update = self.memory.last_update
            # edge_times = pos_graph.ndata['ts']
            # source_nodes = pos_graph.ndata['_ID']
            # source_time_diffs = (edge_times).to(self.device) - last_update[source_nodes].long()
            # #source_time_diffs = (source_time_diffs - self.mean_time_shift_src) / self.std_time_shift_src
            # #没有归一化！！！！
            # time_diffs = source_time_diffs#torch.cat([source_time_diffs, destination_time_diffs, negative_time_diffs],dim=0)


        feat = pos_graph.ndata['feat']#292,172
        if self.use_memory:

            source_nodes = pos_graph.ndata['_ID']
            feat = memory[source_nodes, :] + feat  # 节点信息=节点的记忆信息+节点信息 相当于特征融合的操作

        joined_mail = mail[:,:,:-2]

        if not self.args.no_time: 
            ts = pos_graph.ndata['ts']
            last_update = pos_graph.ndata['last_update']
            mail_time = mail[:,:,-2]
            delta_t_msg = ts.unsqueeze(1) - mail_time
            time_emb_msg = self.time_encoder(delta_t_msg)
            joined_mail = joined_mail + time_emb_msg
            delta_t_feat =  ts.unsqueeze(1) - last_update.unsqueeze(1)
            time_emb_feat = self.time_encoder(delta_t_feat)
            feat = feat + time_emb_feat.squeeze()
        if not self.args.no_pos:
            mail_time = mail[:,:,-2]#295,10
            pos_emb_msg = self.pos_encoder(mail_time)#295,10,175
            joined_mail = joined_mail + pos_emb_msg
        
        attn_output, attn_weight = self.attn_aggr(feat, joined_mail, mask)#294,172   294,10,172   None    attn_output:294,172
        attn_output = self.merger(feat, attn_output)

        if self.use_memory:
            positives = pos_graph.ndata['_ID']
            source_nodes = pos_graph.srcdata['_ID']
            source_node_embedding = pos_graph.srcdata['feat']
            destination_nodes = pos_graph.dstdata['_ID']
            destination_node_embedding = pos_graph.dstdata['feat']
            edge_times = pos_graph.ndata['ts']
            if self.memory_update_at_start:
                # Persist the updates to the memory only for sources and destinations (since now we have
                # new messages for them)

                self.update_memory(positives, self.memory.messages)

                assert torch.allclose(memory[positives], self.memory.get_memory(positives), atol=1e-5), \
                    "Something wrong in how the memory was updated"

                # Remove messages for the positives since we have already updated the memory using them
                self.memory.clear_messages(positives)

            unique_sources, source_id_to_messages = self.get_raw_messages(source_nodes,
                                                                          source_node_embedding,
                                                                          destination_nodes,
                                                                          destination_node_embedding,
                                                                          edge_times)
            unique_destinations, destination_id_to_messages = self.get_raw_messages(destination_nodes,
                                                                                    destination_node_embedding,
                                                                                    source_nodes,
                                                                                    source_node_embedding,
                                                                                    edge_times)
            if self.memory_update_at_start:
                self.memory.store_raw_messages(unique_sources, source_id_to_messages)
                self.memory.store_raw_messages(unique_destinations, destination_id_to_messages)
            else:
                self.update_memory(unique_sources, source_id_to_messages)
                self.update_memory(unique_destinations, destination_id_to_messages)

            if self.dyrep:
                source_node_embedding = memory[source_nodes]
                destination_node_embedding = memory[destination_nodes]
                #negative_node_embedding = memory[negative_nodes]
        return attn_output, attn_weight

def mails_cat(nodes):
    return {'cat_mail': torch.cat([nodes.data['mail'], nodes.data['opposite_mail']],1)}

class mail_attn_agger(nn.Module):
    def __init__(self, emb_dim, n_head=2, dropout=0.1):
        super(mail_attn_agger, self).__init__()
        self.multihead_attn = nn.MultiheadAttention(embed_dim=emb_dim,
                                                    kdim=emb_dim,
                                                    vdim=emb_dim,
                                                    num_heads=n_head,
                                                    dropout=dropout)
        
    # 距离编码、时间编码
    def forward(self, feat, mail, mask):
        mail = mail.permute([1, 0, 2])#10,294,172
        attn_output, attn_weight = self.multihead_attn(feat.unsqueeze(0), mail, mail, mask)#1,294,172   10,294,172   10,294,172
        attn_output, attn_weight = attn_output.squeeze(), attn_weight.squeeze()

        return attn_output, attn_weight

class TimeEncode(torch.nn.Module):

    def __init__(self, dimension):
        super(TimeEncode, self).__init__()

        self.dimension = dimension
        self.w = torch.nn.Linear(1, dimension)

        self.w.weight = torch.nn.Parameter((torch.from_numpy(1 / 10 ** np.linspace(0, 9, dimension)))
                                        .float().reshape(dimension, -1))
        self.w.bias = torch.nn.Parameter(torch.zeros(dimension).float())


    def forward(self, t):
        # t has shape [batch_size, seq_len]
        # Add dimension at the end to apply linear layer --> [batch_size, seq_len, 1]
        t = t.unsqueeze(dim=2)
        # output has shape [batch_size, seq_len, dimension]
        t = self.w(t)
        output = torch.cos(t)
        return output

class PosEncode(nn.Module):
    def __init__(self, expand_dim, seq_len):
        super().__init__()
        
        self.pos_embeddings = nn.Embedding(num_embeddings=seq_len, embedding_dim=expand_dim)
        
    def forward(self, ts):
        # ts: [N, L]
        order = ts.argsort()
        ts_emb = self.pos_embeddings(order)
        return ts_emb

class MergeLayer(torch.nn.Module):
    def __init__(self, in_dim, out_dim, dropout=0.1):
        super().__init__()
        
        self.norm = nn.LayerNorm(in_dim)
        hidden_dim = (in_dim+out_dim)//2
        self.fc1 = nn.Linear(in_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, out_dim)
        self.dropout = nn.Dropout(p=dropout, inplace=True)
        self.relu = nn.ReLU()

        # torch.nn.init.xavier_normal_(self.fc1.weight)
        # torch.nn.init.xavier_normal_(self.fc2.weight)

    def forward(self, x1, x2):
        h = torch.cat([x1, x2], dim=1)
        h = self.norm(h)
        h = self.dropout(h)
        #h = self.norm(h)
        h = self.fc1(h)
        h = self.relu(h)
        #h = self.dropout(h)
        h = self.fc2(h)
        
        return h 